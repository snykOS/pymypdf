import unittest
from mock import *
from rabbit.display import welcome


# class TestDisplay(unittest.TestCase):

# 	def test_it_creates_a_new_object(self):
# 		config = Config()
# 		self.assertTrue(isinstance(config, (Config)))
